# Stručný popis projektu

V rámci tohoto projektu jsem:
- Naimplementoval zadanou funkcionalitu pro **načítání rozhodovacího stromu** a **klasifikaci** nových vstupů (podúkol 1).
- Vytvořil i **trénování stromu** pomocí zjednodušené metody inspirované **CART** (podúkol 2).
- Nepřidával jsem žádné dodatečné rozšíření nad rámec zadání.
- Vše funguje v souladu se zadáním a nebyly zjištěny žádné chyby.
